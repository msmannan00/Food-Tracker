﻿namespace Assets.SimpleFacebookSignIn.Scripts
{
    public enum Implementation
    {
        DeepLinking,
        LoopbackFlow,
        AuthorizationMiddleware
    }
}