﻿using System;

namespace Assets.SimpleFacebookSignIn.Scripts
{
    [Serializable]
    public class UserInfo
    {
        public string id;
        public string name;
        public string email;
    }
}